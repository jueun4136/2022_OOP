package helloYeji;

public class IDException extends Exception {
	public IDException() {
		
	}

	
}
