package helloYeji;

public enum Innerclasskind {
	
	childclass,
	Oldageclass,
	Teenagerclass,
	Adultclass

}
