package Munuchoice;

import Logging.InnerclassViewr;


public class MenuTest {
	public static void main(String[] args) { 
		//MacFrame f = new MacFrame(null);
		
	
	//InnerclassViewr icv = new InnerclassViewr();
    //InnerclassAdder innerclassadder = new InnerclassAdder();
}
}