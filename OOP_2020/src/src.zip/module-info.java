module helloyeji {
	exports helloYeji;
	requires java.logging;
	requires java.desktop;
}